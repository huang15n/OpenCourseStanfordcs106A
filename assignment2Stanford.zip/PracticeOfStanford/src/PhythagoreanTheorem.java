/*
 * 
 */


import acm.program.*;

public class PhythagoreanTheorem extends ConsoleProgram{
	
	
	public void run(){
		runSample();
		
	}
	/** 
	 * this method is to ask users for input 
	 * get the first input as value a 
	 * get the second input as value b 
	 * then output the result 
	 */
	
	public void runSample(){
		println("Enter the value compute Pthythagorean Theorem");
		int a = readInt("a:");
		int b = readInt("b:");
		println("c = " + computeTheResult(a,b));
	}
	
	/**
	 * 
	 * this method is to compute the value of the phythagorean theorem
	 * a^2 + b^2 = c^2
	 */
	public double computeTheResult(int a, int b){

		return Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
		
	}
	
	
	
	
	
	
	

}
