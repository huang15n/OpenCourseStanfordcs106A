import acm.program.*;

public class FindRange extends ConsoleProgram{
	
	public void run(){
		/**
		 * these variables are the number for the user input 
		 * the min value set the large amount in order to do the comparison 
		 * the max value set the extremely small in order to do get the maximum 
		 */
		int number;
		int minValue = 99999;
		int maxValue = -99999;
		
		
		/* run sample */
		println("This program finds the largest and smallest numbers :");
		/* this is tabout read input ,comparions between the value with the current value */
		while(((number = readInt("?")) != 0)){
			minValue = Math.min(number, minValue);
			maxValue = Math.max(number, maxValue);
		}
		/* output the result and printout in the screen */
		println("smallest:"+minValue);
		println("largest:"+maxValue);
		
		
	}
	
	
	
	
	
}
