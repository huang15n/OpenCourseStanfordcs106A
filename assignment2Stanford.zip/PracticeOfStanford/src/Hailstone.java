/*
 * Eddie Huang 24 June 2017 
 * question6 of cs106a from stanford university 
 * this test program totally follows the formulas of the Hofstadter's book 
 * and it tests vintage edition of the problem he illustrates 
 * 
 * 
 */

import acm.program.*;


public class Hailstone extends ConsoleProgram {
	
	public void run(){
		/* to declare the variable to store user's input */
		int number;
		number = readInt("Enter a number:");
		/* pass the value into the process and make it work */
		hailstoneProcess(number);
		
		
	}
	
	
	/**
	 * this is the main design of the process 
	 * the funtion is written in accordance iwht 
	 * Hofstadter's theory . 
	 * the formula is that 
	 * we test a number based on the rule   if that is not 1 
	 * while the number is even we use this to divided by 2 
	 * if that is odd ,we use the number to multiplied by 3 + 1 
	 * the loop will end until the number reaches 1 and output the result 
	 *  
	 */
	
	public void hailstoneProcess(int number){
		/*This is to test the steps that we need to use for the program */
		int steps = 1;
		/* this is the implemenation of the method that i wrote */
		while(number != 1 )
		{
			if(number % 2 == 0)
			{
			  println(number +" is even so I take the half:" + (number / 2));
			  number /= 2;
			}
			else 
			{
				println(number+" is odd,so I take 3n + 1:"+(number * 3 + 1));
				number = number * 3 + 1;
			}
			steps++;
		}
		
		/* eventually we get the output and respond to users */
		println("The process took "+steps+" to reach 1");
		
		
		
		
	}
	
	

}
