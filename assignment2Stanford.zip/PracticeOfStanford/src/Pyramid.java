/*
 * Eddie Huang 24 June 2017 
 * Copyright (c) 2017 
 * This software is designed to full the requirement of the assignment 2 
 * of Stanford University .
 * the purpose of the assignment2 question1 is that 
 * you should design a pile of bricks which make a shape of prymaid 
 * the algorithm derived and the inspiration sparkled by a simple matter of fact that 
 * the prymaid should be arrange in a ascending order up from the top 
 * however , each prymaid has to lay each by each and the gap between each two bricks is the middle line 
 * of the structure above 
 * 
 * 
 */
import acm.program.*;
import acm.graphics.*;
public class Pyramid extends GraphicsProgram{
	/** This is to declare the width of each brick */
	private static final int BRICK_WIDTH = 30;
	/** This is to declare the height of each brick */
	private static final int BRICK_HEIGHT = 12;
	
	/** This is to declare the base of the prymaid ,which is also the bottom */
	private static final int BRICKS_IN_BASE = 14;

	
	
	public void run(){
		makeBricks();
	}
	
	/**
	 * this is the method to make bricks that we are able to work on the certain patterns 
	 * the double layers of loops actually layout the bricks that we are able to make two dimensional bricks 
	 * the prymaid myth is not really difficult to make and the math question coming here is that how would you like to make exactly the same 
	 * shape as what people will do
	 * one thing to remember is that the inner loop in two dimensional loops always controls the line or cols like *******
	 * and the outloop controls the rows like 
	 * *****
	 * ***** 
	 * this 5 x 2 and in programming ,you should write the loop as 
	 * for(int i = 1 ; i <= 2; i++)
	 * for(int j = 1; j <=5; j++)
	 * the thing that i should mention here is how you are about to make the arrangement 
	 * which is not tricky ,but the mechanism of the acm.graphics has to be consider 
	 * the pixels is defined as the constants . you see the middle point of each bricks in increasing orders will be the edge of the above level 
	 * if you aligh that ,you will find the pattern that each one based on 0.5 in decreasing order 
	 * the rule is simple make the variable k outside of the loop which is equal to the total number of bricks 
	 * use this to be evenly divided by 2 and use that to minus 0.5 each time 
	 * 
	 * 
	 */
	
	public void makeBricks(){
		/* this is the variable to declare the change in each alignment */
		double k = BRICKS_IN_BASE / 2;
		
		/* this is the rows of the bricks */
		for(int i = 1 ; i <= BRICKS_IN_BASE; i++){
		    	 for(int j = 1; j <= i; j++){
		    		 /* this is the columns of the bricks */
		    	 add(new GRect(BRICK_WIDTH, BRICK_HEIGHT), BRICK_WIDTH *( j + k ), BRICK_HEIGHT * i);
		    	 }
		    	 /* this variable is meant to set the pattern */
		    	 k -= 0.5;
		    	 
	
		}
		
	
	}

}
/**
 * you might ask the reason why we do not set the third loop to do the work ? 
 * the reason is simple . the loop should strictly work the integers 
 * besides , the third layer loop will also make the bricks iterate the whole process again which 
 * is not desirable in our case 
 * 
 */
	

 
