

/*
 * Eddie Huang 24 June 2017
 * This program meets the requirement of stanford cs106a program hierachy tree design 
 * in order to achieve the effect ,please understand the use of the gui of acm first 
 * then is about time to know about pixels that is required to obtain the knowledge of arranging things properly 
 * 
 */


import acm.graphics.*;
import acm.program.*;


public class ProgramHierachy extends GraphicsProgram{
	
	/* the height of the individual box */
	private static final int HEIGHT_BOX = 60;
	/* the width of the individual box */
	private static final int WIDTH_BOX = 200;
	/* the gap among three boxes */
	private static final int GAP = 10;
	/* the line length of two side lines */
	private static final int LINE_LENGTH = 60;
	
	/*  the original ordinates of the central box */
	private static final double X = 400;
	
	private static final double Y = 200; 
	
	public void run(){
	drawBoxes();
	drawLines();
	fillTheBoxes();
	}
	
	
	public void drawBoxes(){
		drawSingleBox();
	}
	/**
	 * this method is designed to get the rectangle boxes in order to
	 * establish the basic hierachy shape for the line connects 
	 * i here creates 4 GRect obejcts and accordingly set desirable distance that they 
	 * should align with 
	 */
	public void drawSingleBox(){
		/* the creation of retangle objects  and they have the same size */
		GRect box1 = new GRect(WIDTH_BOX, HEIGHT_BOX); // width 200 height 60 
		GRect box2 = new GRect(WIDTH_BOX, HEIGHT_BOX);
		GRect box3 = new GRect(WIDTH_BOX, HEIGHT_BOX);
		GRect box4 = new GRect(WIDTH_BOX, HEIGHT_BOX);
		/* set the position of each object */
	    add(box1, X, Y);
	    add(box2,  X - WIDTH_BOX * 1.5, HEIGHT_BOX * 2 + Y);
	    add(box3,  X , HEIGHT_BOX * 2 + Y);
	    add(box4 , X + WIDTH_BOX * 1.5,   HEIGHT_BOX * 2 + Y);
	}
	
	/**
	 * this method is intended to draw line in the hierachical tree 
	 * in order to connect them in the right node ,the location has to be more precise  
	 * the logic is that each middle center of the box has to be define through (its starting coordinates + box width , its starting height adjusted ) 
	 * 
	 */
	public void drawLines(){
		GLine line1 = new GLine(((X + WIDTH_BOX / 2) ), Y + HEIGHT_BOX , ((X - WIDTH_BOX * 1.5) + WIDTH_BOX / 2 ) , HEIGHT_BOX * 2 + Y );
	    GLine line2 = new GLine(((X + WIDTH_BOX / 2) ), Y + HEIGHT_BOX ,((X + WIDTH_BOX / 2) ), Y + HEIGHT_BOX * 2 );
	    GLine line3 = new GLine(((X + WIDTH_BOX / 2) ), Y + HEIGHT_BOX ,((X + WIDTH_BOX * 1.5) + WIDTH_BOX / 2) , HEIGHT_BOX * 2 + Y );
        add(line1);	
        add(line2);
        add(line3);
	
	}
	
	
	/**
	 * this method to fill the graph with detail labels and information to complete the whole tree 
	 * and the thing to notice as well as the coordinates that we want to set in  
	 * my strategy of those object is still to create first then use them .
	 */
	
	public void fillTheBoxes(){
		
		GLabel label1 = new GLabel("Program",X + GAP * 3, Y + GAP * 3);
		GLabel label2 = new GLabel("GraphicsProgram", X - WIDTH_BOX * 1.5 + GAP * 3, HEIGHT_BOX * 2 + Y + GAP * 3);
		GLabel label3 = new GLabel("ConsoleProgram",  X + GAP * 3 , HEIGHT_BOX * 2 + Y + GAP * 3);
		GLabel label4 = new GLabel("DialogProgram",X + WIDTH_BOX * 1.5 + GAP * 3,   HEIGHT_BOX * 2 + Y + GAP * 3);
		 
		add(label1); 
		add(label2);
		add(label3);
		add(label4);
		
		
	}
	
	
	

}
