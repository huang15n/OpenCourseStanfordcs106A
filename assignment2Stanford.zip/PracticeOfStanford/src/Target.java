import acm.program.*;
import acm.graphics.*;
import java.awt.*;


public class Target extends GraphicsProgram{
	
	/* this is to declare the outer circle raidus */
	private static final double OUTER_CIRCLE = 72;
	/* this is to declare the middle circle radius */
	private static final double MIDDLE_CIRCLE = OUTER_CIRCLE * 0.65;
	/* this is the declare the inner circle */
	private static final double INNER_CIRCLE = OUTER_CIRCLE * 0.3;
	
	/* set the color as red*/
	private static final Color RED = Color.RED;
	
	/* set the color as white */
	private static final Color WHITE = Color.WHITE;
	
	public void run(){
		setSmallerCircle();
	}
	
	
	public void setSmallerCircle(){
		GOval smallerCircle = new GOval(OUTER_CIRCLE, OUTER_CIRCLE);
		smallerCircle.setFillColor(Color.red);
		 
		double xSmaller = (getWidth() - smallerCircle.getWidth() / 2);
		double ySmaller = (getHeight() - smallerCircle.getHeight() / 2);
	    add(smallerCircle, xSmaller, ySmaller);
	    smallerCircle.setLocation(200, 200);
	}
	

}
